import java.util.Scanner;

public class ExFor4 {

    public static void main(String[] args) {
        
    Scanner teclado = new Scanner (System.in);

    int valor, maior, i;

    System.out.println("Informa um valor: ");
    valor = teclado.nextInt();
    maior=valor;

    for(i = 1; i <=4;i++){

        System.out.println("Informe um valor: ");
        valor = teclado.nextInt();

    }if(valor>maior){

        maior=valor;

    }

    System.out.println("O maior valor é: " + maior);

    }

}
