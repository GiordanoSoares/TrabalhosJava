public class ExFor11 {
    
    public static void main(String[] args) {
        
        /* 11. Desenvolva um software que mostre os números ímpares de 1 até 15. */

        for(int i = 1; i <=15; i++){

            if(i % 2 == 1){

                System.out.println("Número ímpar: " + i);
    
            }

        }

    }

}
