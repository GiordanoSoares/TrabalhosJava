public class EstruturaRepeticao2 {
    
    public static void main(String[] args) {
        
        for(int i = 50; i <= 100; i++){

            if(i % 2 == 0){
                System.out.println("Pares: " + i);
            }else{
                System.out.println("ímpares: " + i);
            }
        }

    }

}
