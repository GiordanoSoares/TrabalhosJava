
import java.util.Scanner;

public class ExFor24 {
    
    public static void main(String[] args) {
        
        /* 24. Ler um número inteiro n. Escrever a soma de todos os números pares
        de 2 até n. */

        Scanner teclado = new Scanner(System.in);
    
        int i, valor, soma = 0;

        System.out.println("Informe um valor: ");
        valor = teclado.nextInt();

        for(i = 2; i <=valor; i++){

            if(i % 2 == 0){

                soma=soma+i;

            }

            System.out.println("A soma dos números pares é: " + soma);

        }

    }

}
