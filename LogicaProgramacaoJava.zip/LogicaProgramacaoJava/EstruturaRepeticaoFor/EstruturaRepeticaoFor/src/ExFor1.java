public class ExFor1 {
    
    public static void main(String[] args) {
        
        /* 1. Utilizando o comando for, mostre na tela os valores 120, 115, 110, 105,
        100, 95, 90, 85 e 80 na tela. */

        for(int i = 120; i >=80; i-=5){

            System.out.println(i);

        }

    }

}
