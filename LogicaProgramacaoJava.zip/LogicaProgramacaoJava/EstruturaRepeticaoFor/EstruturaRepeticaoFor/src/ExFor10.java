public class ExFor10 {
    
    public static void main(String[] args) {
        
        /* Escreva um programa que imprima todos os numeros de 1 a 100 */


        for(int i = 1; i <=100; i++){

            System.out.println("Numeros entre 1 a 100: " + i);

        }

    }

}
