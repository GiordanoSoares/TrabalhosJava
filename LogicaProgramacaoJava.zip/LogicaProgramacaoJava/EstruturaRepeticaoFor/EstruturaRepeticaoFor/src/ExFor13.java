
import java.util.Scanner;

public class ExFor13 {
    
    public static void main(String[] args) {
        
        /* 13. Leia sete números e mostre o valor da soma dos sete números. */

        Scanner teclado = new Scanner (System.in);

        int valor, soma = 0, i;

        for(i = 1; i <=7; i++){

            System.out.println("Informe um valor: " + i);
            valor = teclado.nextInt();

            soma+=valor;

        }

        System.out.println("A soma total é: " + soma);

    }

}
