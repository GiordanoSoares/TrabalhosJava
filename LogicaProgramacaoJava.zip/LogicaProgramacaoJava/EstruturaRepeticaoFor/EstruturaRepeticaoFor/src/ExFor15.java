import java.util.Scanner;

public class ExFor15 {
    
    public static void main(String[] args) {
        
        /* 15. Escreva um programa que peça um número inteiro positivo e escreva
        todos os números inteiros entre 1 e esse número. */

        Scanner teclado = new Scanner (System.in);

        int valor, i;

        System.out.println("Informa um valor: ");
        valor = teclado.nextInt();

        for(i = 1; i <=valor; i++){

            System.out.println("Valores: " + i);

        }

    }

}
