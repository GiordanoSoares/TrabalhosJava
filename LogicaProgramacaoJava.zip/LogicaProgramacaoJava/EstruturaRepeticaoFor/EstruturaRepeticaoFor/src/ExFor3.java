public class ExFor3 {
    
    public static void main(String[] args) {
        
        /*3. Utilizando o comando for mostre a tabuada do 5 na tela. */

        for(int i = 0; i <=100; i++){

            if (i % 5 == 0) {
                System.out.println("Tabuada do 5: " + i);
            }

        }

    }

}
