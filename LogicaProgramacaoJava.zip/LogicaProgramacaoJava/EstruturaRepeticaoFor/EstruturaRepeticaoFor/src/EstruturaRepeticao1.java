public class  EstruturaRepeticao1{
    public static void main(String[] args) throws Exception {

        for (int i = 10; i >= 0; i--) {
            
            System.out.println(i);

        }

    }
}
