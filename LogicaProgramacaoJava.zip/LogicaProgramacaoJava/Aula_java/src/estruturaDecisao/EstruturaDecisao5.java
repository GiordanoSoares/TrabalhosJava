/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estruturaDecisao;

import java.util.Scanner;


public class EstruturaDecisao5 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        //Switch
        int escolha = 3;
        
        switch(escolha){
        
            case 1:
                System.out.println("Esta no caso 1");
            break;
            
            case 2:
                System.out.println("Esta no caso 2");
            break;
            
            case 3:
                System.out.println("Esta no caso 3");
            break;
            
            default:
                System.out.println("Esta no ultimo caso");
        }
        
    }
    
}
