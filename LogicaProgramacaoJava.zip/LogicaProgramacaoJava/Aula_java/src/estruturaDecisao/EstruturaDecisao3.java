/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estruturaDecisao;

import java.util.Scanner;

public class EstruturaDecisao3 {
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        String usuario , senha;
        
        System.out.println("Digite seu Usuario: ");
        usuario = teclado.nextLine();
        
        System.out.println("Digite sua Senha: ");
        senha = teclado.nextLine();
        
        //equals only for String
        
        if(usuario.equals("giordano") && senha.equals("12345")){
            System.out.println("Logado com sucesso");
        }else{
            System.out.println("Verifique seu Usuario ou Senha");
        }
    }
    
}
