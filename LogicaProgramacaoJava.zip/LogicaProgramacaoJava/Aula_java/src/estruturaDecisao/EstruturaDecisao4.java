/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estruturaDecisao;

import java.util.Scanner;

public class EstruturaDecisao4 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        double salario;
        
        System.out.println("Digite seu salario: ");
        
        salario = teclado.nextDouble();
        
        if (salario <= 1000){
            
            System.out.println("Será descontado 5%, equivalente a: R$" + (salario*0.05) );
            
        }else if (salario <= 1500){
        
            System.out.println("Será descontado 7%, equivalente a: R$" + (salario*0.07));
        
        }else if (salario <= 2500){
        
            System.out.println("Será descontado 9%, equivalente a: R$" + (salario*0.09));
        
        }else if (salario <=4000){
        
            System.out.println("Será descontado 15%, equivalente a: R$" + (salario*0.15));
        
        }else {
        
            System.out.println("Será descontado 18%, equivalente a: R$" + (salario*0.18));
        
        }
        
    }
    
}
