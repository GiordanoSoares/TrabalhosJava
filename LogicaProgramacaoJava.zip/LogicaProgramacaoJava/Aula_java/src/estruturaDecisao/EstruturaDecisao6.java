/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estruturaDecisao;

import java.util.Scanner;

public class EstruturaDecisao6 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        //Menu do sistena
        int opcao;
        boolean sair = true;

        System.out.println(" Digite 1 para cadastro de CLientes \n Digite 2 para cadastro de Fornecedor \n Digite 3 para cadastro de Produtos \n Digite 4 para Usuarios \n Digite 5 para Sair");
        opcao = teclado.nextInt();

        switch (opcao) {

            case 1:
                System.out.println("Cadastro de Clientes");
                break;

            case 2:
                System.out.println("Cadastro de Fornecedor");
                break;

            case 3:
                System.out.println("Cadastro de Produtos");
                break;

            case 4:
                System.out.println("Cadastro de Usuarios");
                break;
                
            case 5:
                sair = false;
                System.out.println(sair);
                System.out.println("Saiu do Sistema");
                break;
                
            default:
                System.out.println("Menu não encontrado");
        }

    }

}
