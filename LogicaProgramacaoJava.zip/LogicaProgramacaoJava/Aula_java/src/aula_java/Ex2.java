/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex2 {
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a base de seu triangulo: ");
        float b = teclado.nextFloat();
        System.out.println("Digite a altura de seu triangulo: ");
        float h = teclado.nextFloat();
        float a = (b*h)/2;
        System.out.println("A área de seu triangulo é: " + a);
        
        //Aprovado
    }
}
