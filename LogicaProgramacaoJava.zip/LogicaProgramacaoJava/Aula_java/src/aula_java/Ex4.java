/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex4 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Diga o valor A: ");
        int a = teclado.nextInt();
        System.out.println("Diga o valor B: ");
        int b = teclado.nextInt();
        int resultA = (a+b) - a;
        int resultB = (a+b) - b;
        System.out.println("O valor A era: " + a + " e agr é: " + resultA + " O valor B era: " + b + " e agr é: " + resultB);
        
        
    }
    
}
