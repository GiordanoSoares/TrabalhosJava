/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;


public class Ex6 {
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
       
        System.out.println("Diga o Comprimento: ");
        float c = teclado.nextFloat();
        System.out.println("Diga a Largura: ");
        float l = teclado.nextFloat();
        System.out.println("Diga a Altura");
        float h = teclado.nextFloat();
        
        float volume  = (c*l*h);
        
        System.out.println("O resultado é: " + volume);
          
    }
    
}
