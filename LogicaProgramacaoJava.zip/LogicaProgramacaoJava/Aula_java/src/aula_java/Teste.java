/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;


public class Teste {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a primeira nota: ");
        float n1 = teclado.nextFloat();
        
        System.out.println("Digite a segunda nota: ");
        float n2 = teclado.nextFloat();
        float m = (n1+n2)/2;
        
        System.out.println("Sua média é: " + m);
        
        if (m > 9)
        {
            System.out.println("Parabéns");
            
            teclado.close();
        }
        
    }
    
}
