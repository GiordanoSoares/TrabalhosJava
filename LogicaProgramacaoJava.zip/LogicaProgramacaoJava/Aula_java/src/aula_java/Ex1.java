/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex1 {
    
    public static void main(String[] args) {
        
        //Atalhos: sout, psvm
        //Lembrar de dar import no scanner
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a primeira nota: ");
        
        //Chamar a classe certa Ex.: String = nextline, Float = nextfloat.
        
        float n1 = teclado.nextFloat();
        System.out.println("Digite a segunda nota: ");
        float n2 = teclado.nextFloat();
        float resultado = (n1+n2)/2;
        System.out.println("O resultado da média é: " + resultado);
        
    }
    
}
