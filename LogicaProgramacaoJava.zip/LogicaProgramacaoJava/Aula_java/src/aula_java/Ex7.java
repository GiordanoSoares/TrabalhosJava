/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;


public class Ex7 {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        //double salario,bonus,desconto,total
        
        System.out.println("Diga o seu salário base: ");
        
        double salario = teclado.nextDouble();
        double result = (salario*1.20*0.93);
        
        System.out.println("O total é: " + result);
        
        /*
        double salario = teclado.nextDouble();
        double bonus = (salario*0.2);
        double desconto = (salario*0.07);
        double total = (salario - desconto)+bonus;
        
        System.out.println("Restou:" + total);*/
        
    }
    
}
