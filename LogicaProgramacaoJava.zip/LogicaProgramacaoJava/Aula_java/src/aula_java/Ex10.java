/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex10 {
    
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Uma duzia de laranja custa R$6,00. Diga quantas duzias vc deseja comprar: ");
        System.out.println("10% DE DESCONTO POR DUZIA APROVEITE!!!!");
        
        float duzia = teclado.nextFloat();
        
        double descPerDuzia = duzia*(12.00*0.90);
        double precoSemDesc = (duzia*12.00);
        double desconto = (12.00*0.10);
        float totalLaranja = (duzia*12);
        double precoTotal = duzia*descPerDuzia;
        double troco = (precoTotal - precoSemDesc);
        
        System.out.println("O preco sem desconto sera: R$" + precoSemDesc + " desconto por laranja: " + desconto + " Numero total de laranja: " + totalLaranja + " Quanto a ser pago: " + precoTotal + " E o troco: " + troco );
    }
}
