/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.text.DecimalFormat;

public class Aula_2 {
    
    public static void main(String[] args) {
        
        DecimalFormat casas = new DecimalFormat ("#.####");
        
        float n1 = 7.698f;
        float n2 = 8.658f;
        float resposta = (n1/n2);
        
        System.out.println(casas.format(resposta));
    }
}
