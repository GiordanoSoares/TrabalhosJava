/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Aula_3 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        //Valores Digitados pelo Usuario (basicamente um label)
        
        System.out.println("Digite seu nome: ");
        String nome = teclado.nextLine();
        System.out.println("O nome é: " + nome);
        
        //Campo email
        
        System.out.println("Digite seu email: ");
        String email = teclado.nextLine();
        System.out.println("O seu email é: " + email);
        
        //Bairro
        
        System.out.println("Digite seu bairro:");
        String bairro = teclado.nextLine();
        System.out.println("O seu bairro é: " + bairro);
        
        //Rua
        
        System.out.println("Digite sua rua: ");
        String rua = teclado.nextLine();
        System.out.println("Sua rua é: " + rua);
        
    }
}
