/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula_java;

public class Aula_java {

    public static void main(String[] args) {
        
        String nome = "Brian";
        int idade = 14;
        float altura = 1.85f;
        
        //Operaçôes Matemáticas
        int n1 = 10;
        int n2 = 20;
        
        int soma = (n1 + n2);
        int subtrai = (n1 - n2);
        int multi = (n1*n2);
        float div = (n1/n2);
        
        System.out.println("O nome é: " + nome + " A idade é: " + idade + " A altura é: " + altura );
        System.out.println("A soma é: " + soma );
        System.out.println("A subtração é: " + subtrai );
        System.out.println("A multiplicação é: " + multi );
        System.out.println("A divisão é: " + div );
        
    }
    
}
