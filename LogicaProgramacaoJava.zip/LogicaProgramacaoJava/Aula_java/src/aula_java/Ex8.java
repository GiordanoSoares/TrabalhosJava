/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;


public class Ex8 {
    
    public static void main(String[] args) {
        
        /*DISTÂNCIA = TEMPO * VELOCIDADE.
        LITROS_USADOS = DISTÂNCIA / 12.*/
       
        Scanner teclado = new Scanner(System.in);
        System.out.println("Diga o seu tempo: ");
        float tempo = teclado.nextFloat();
        System.out.println("Diga a sua velocidade: ");
        float vel = teclado.nextFloat();
        float distancia = (tempo*vel);
        float litros = (distancia/12);
        
        System.out.println("A velocidade media é: " + vel);
        System.out.println("O tempo gasto é: " + tempo);
        System.out.println("A distancia é: " + distancia);
        System.out.println("Litros gastos: " + litros);
        
        
        
    }
    
}
