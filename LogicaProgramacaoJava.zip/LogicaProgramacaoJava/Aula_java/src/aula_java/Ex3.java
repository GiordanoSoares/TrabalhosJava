/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex3 {
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Diga seu salario bruto: ");
        double salario = teclado.nextDouble();
        double resultado = (salario*0.9*0.7);
        System.out.println("Resultado final foi: " + resultado);
        
    }
    
}
