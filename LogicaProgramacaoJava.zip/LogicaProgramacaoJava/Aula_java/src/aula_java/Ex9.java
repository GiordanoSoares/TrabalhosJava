/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;


public class Ex9 {
    
    
    public static void main(String[] args) {
       
       Scanner teclado = new Scanner(System.in);
       
        System.out.println("Diga a sua idade: ");
        int age = teclado.nextInt();
        int meses = (age*12);
        int dias = (age*365);
        
        System.out.println("Sua idade em anos: " + age + " Sua idade em meses: " + meses + " Sua idade em dias: " + dias);
       
    }
}
