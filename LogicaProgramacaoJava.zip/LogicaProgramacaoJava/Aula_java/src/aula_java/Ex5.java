/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_java;

import java.util.Scanner;

public class Ex5 {
    
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Diga o primeiro valor: ");
        int a1 = teclado.nextInt();
        System.out.println("Diga o segundo valor: ");
        int a2 = teclado.nextInt();
        System.out.println("Diga o terceiro valor: ");
        int a3 = teclado.nextInt();
        int soma = (a1+a2+a3)*(a1+a2+a3);
        System.out.println("A soma de " + a1 + a2 + a3 + " elevado ao quadrado é: " + soma);
        
    }
    
}
