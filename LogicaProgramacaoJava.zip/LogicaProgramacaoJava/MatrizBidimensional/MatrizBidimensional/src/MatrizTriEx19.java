import java.util.Scanner;

public class MatrizTriEx19 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int matriz[][][] = new int[3][3][3];

        int quantidade = 0;

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Informe os valores: ");

                    matriz[i][j][k] = teclado.nextInt();

                    if(matriz[i][j][k] == 5){

                        quantidade++;

                    }

                }

            }

        }

        System.out.println("Quantidade de vezes que apareceu o 5: " + quantidade);

        teclado.close();

    }

}
