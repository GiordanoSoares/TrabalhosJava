
import java.util.Scanner;

public class MatrizBiExemplo {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        //Declaracao da Matriz biDimensional

        int [][] brian = new int[2][2];
        int soma = 0;

        for(int i = 0; i <brian.length; i++){
            
            //System.out.println("Valores de I" + " [" + i + "]" );

            for(int j = 0; j < brian.length; j++){

                System.out.println("Valores de I e J" + " [" + i + "]" + "[" + j + "]" );

                brian[i][j] = teclado.nextInt();

                soma+=brian[i][j];

            }
            
        }

        //Imprimir matriz Bidimensional

        for(int i = 0; i < brian.length; i++){

            for(int j = 0; j < brian.length; j++){

                System.out.println("Valores da Matriz Bi " + brian[i][j]);

            }

        }

        System.out.println("\nSoma é: " + soma);

    }

}
