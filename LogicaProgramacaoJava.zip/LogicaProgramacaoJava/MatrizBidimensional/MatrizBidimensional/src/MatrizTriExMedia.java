
import java.util.Scanner;

public class MatrizTriExMedia {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int matriz[][][] = new int[2][2][2];
        double soma = 0;

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Informe os valores: ");

                    matriz[i][j][k] = teclado.nextInt();

                    soma+=matriz[i][j][k];

                }

            }
            
        }

        double media = soma/(2*2*2);

        System.out.println("A média é: " + media);

    }

}
