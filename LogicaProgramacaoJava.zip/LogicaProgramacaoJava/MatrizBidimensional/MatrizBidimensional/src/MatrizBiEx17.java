import java.util.Scanner;

public class MatrizBiEx17 {
    
    public static void main(String[] args) {
        
        /* Insira uma matriz 2x2 */

        Scanner teclado = new Scanner(System.in);

        int[][] matriz = new int[2][2];

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                System.out.println("Insira o valor de ["+i+"] e [" + j +"]");

                matriz[i][j] = teclado.nextInt();

            }

        }

        
        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                System.out.println("Valores da Matriz Bi " + matriz[i][j]);

            }

        }


    }

}
