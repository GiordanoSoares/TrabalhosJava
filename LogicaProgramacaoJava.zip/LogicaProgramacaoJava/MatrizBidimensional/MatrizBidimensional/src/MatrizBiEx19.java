import java.util.Scanner;

public class MatrizBiEx19 {
    
    public static void main(String[] args) {
        
        /* 19. Leia uma matriz 2X2 e verifique quantas vezes aparece o valor 5 na
            matriz. */

        Scanner teclado = new Scanner(System.in);

        int matriz[][] = new int[2][2];
        int quantidade = 0;

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                System.out.println("Informe o valor: ");

                matriz[i][j] = teclado.nextInt();

                if(matriz[i][j] == 5){

                    quantidade++;

                }


            }

        }

        System.out.println("Apareceu o número 5 = " + quantidade );
    }

}
