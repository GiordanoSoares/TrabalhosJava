import java.util.Scanner;

public class MatrizTriEx17 {
    
    public static void main(String[] args) {
        
        /* Declare uma matriz 3x3x3 */

        Scanner teclado = new Scanner(System.in);

        int matriz[][][] = new int[3][3][3];

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Informe os valores: ");

                    matriz[i][j][k] = teclado.nextInt();

                }

            }
            
        }

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Valores informados: " + matriz[i][j][k]);

                }

            }
            
        }

    }

}
