
import java.util.Scanner;

public class MatrizTriPares {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int matriz[][][] = new int[2][2][2];
        int pares = 0;

        for(int i = 0; i<matriz.length; i++){

            for(int j = 0; j<matriz.length; j++){

                for(int k = 0; k<matriz.length; k++){

                    System.out.println("Informe os valores: ");

                    matriz[i][j][k] = teclado.nextInt();

                    if(matriz[i][j][k]%2 == 0){

                        pares++;

                    }

                }
        

            }
    

        }

        System.out.println("Dos números digitados, a quantidade de pares informados foi: " + pares);

    }

}
