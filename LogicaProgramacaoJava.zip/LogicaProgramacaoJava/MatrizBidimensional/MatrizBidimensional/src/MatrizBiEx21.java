import java.util.Scanner;

public class MatrizBiEx21 {
    
    public static void main(String[] args) {
        
        /* 21. Faça um software que leia uma matriz 2X2, a seguir multiplique cada
        elemento da matriz lida por 2 e escreva na tela o resultado. */

        Scanner teclado = new Scanner(System.in);

        int matriz[][] = new int[2][2];


        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                System.out.println("Informe o valor: ");

                matriz[i][j] = teclado.nextInt();

            }

        }

        for(int i = 0; i < matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                System.out.println("Números informados só que o dobro: " + (matriz[i][j]*2));
            }

        }
        
    }

}
