
import java.util.Scanner;

public class MatrizTriDimensional {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int[][][] matriz = new int[3][3][3];

        for(int i = 0; i <matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Valores para: " + i + " - " + j + " - " + k);

                    matriz[i][j][k] = teclado.nextInt();

                }

            }

        }

        for(int i = 0; i <matriz.length; i++){

            for(int j = 0; j < matriz.length; j++){

                for(int k = 0; k < matriz.length; k++){

                    System.out.println("Valores adicionados: " + matriz[i][j][k]);

                }

            }

        }

    }

}
