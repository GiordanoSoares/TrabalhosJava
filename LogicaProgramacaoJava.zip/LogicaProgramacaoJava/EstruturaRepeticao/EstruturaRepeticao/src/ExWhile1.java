public class ExWhile1 {
    
    public static void main(String[] args) {
        
        /*1) Escreva um programa que imprima todos os números compreendidos
        entre 1 e 100. (Responda com o - while) Pode ser utilizado o for. É
        mais comun com o “for”. */

        int i = 1;

        while( i <=100){

            System.out.println("Impressões: " + i);

            i++;


        }

    }

}
