public class ExWhile3 {
    
    public static void main(String[] args) {
        
        /*3) Utilizando While - Faça um programa em Java que mostra os números
        pares de 0 a 100. */

        int i = 0;

        while( i <=100){

            System.out.println("Impressão: " + i);

            i+=2;

        }

    }
    
}
