public class ExWhile5 {
    
    public static void main(String[] args) {
        
        //mesma coisa que o exercicio 1

    }
    
}
