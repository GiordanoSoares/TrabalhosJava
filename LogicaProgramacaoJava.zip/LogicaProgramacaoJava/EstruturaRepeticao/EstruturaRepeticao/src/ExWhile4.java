public class ExWhile4 {
    
    public static void main(String[] args) {
        
        /*4) Utilizando While - Supondo que a população de um país A seja da ordem
        de 90.000 de habitantes com uma taxa anual de crescimento de 3% e que
        a população de um país B seja, aproximadamente, de 200.000 de
        habitantes com uma taxa anual de crescimento de 1,5%, fazer um
        algoritmo que calcule e escreva o numero de anos necessários para que a
        população do país A ultrapasse ou iguale a população do país B, mantidas
        essas taxas de crescimento. */

        int a = 90000;
        int b = 200000;

        int y = 0;


        while(a <  b){

            a += (a/100) * 3;
            b += (b/100) * 1.5;

            y++;

        }

        /* Ficou fora do while pra n repetirem toda hora */

        System.out.println("A " + a);
        System.out.println("B " + b);
        System.out.println("Anos necessários: " + y);

    }

}
