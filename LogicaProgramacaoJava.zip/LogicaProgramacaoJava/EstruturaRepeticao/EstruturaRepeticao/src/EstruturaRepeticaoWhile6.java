public class EstruturaRepeticaoWhile6 {
    
    public static void main(String[] args) {
        
        int i = 20;

        while( i >=20 && i <=200){

            System.out.println("Impressão: " + i);

            i++;

        }

    }
    
}
