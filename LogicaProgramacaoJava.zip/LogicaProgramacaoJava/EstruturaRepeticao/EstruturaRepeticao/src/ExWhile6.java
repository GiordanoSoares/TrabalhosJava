public class ExWhile6 {
    
    public static void main(String[] args) {
        
        /* 6) Utilizando o comando for mostre a tabuada do 5 na tela. */

        int i = 0;

        while(i <=1000){

            i+=5;

            System.out.println("Tabuada do 5 até 1000: " +i);

        }

    }

}
