public class EstruturaRepeticaoWhile3 {
    

    public static void main(String[] args) {
        
        int i = 0;

        while (i <=3) { 
            
            System.out.println("Digite a nota: " + i);

            i++;

        }
        
    }
}
