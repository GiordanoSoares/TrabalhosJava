
public class TentativaFor {
    
    public static void main(String[] args) {
        
       /*  for (int i = 1; i <=10; i++){

            System.out.println("Teste");

        } */

        /* 1) Escreva um programa que imprima todos os números compreendidos
        entre 1 e 100. (Responda com o - while) Pode ser utilizado o for. É
        mais comun com o “for”. */

        /*for (int i = 1; i <=100; i++){

            System.out.println(i);

        }*/

        /*2) Utilizando While - Faça um programa em Java que mostra os números
        ímpares de 0 a 100. */

        /*for (int i = 1; i >=0 && i <=100;i+=2){

            System.out.println(i);

        }*/

        /*3) Utilizando While - Faça um programa em Java que mostra os números
        pares de 0 a 100. */

        /*for (int i = 0; i <=100;i+=2){

            System.out.println(i);

        }*/

        /*4) Utilizando While - Supondo que a população de um país A seja da ordem
        de 90.000 de habitantes com uma taxa anual de crescimento de 3% e que
        a população de um país B seja, aproximadamente, de 200.000 de
        habitantes com uma taxa anual de crescimento de 1,5%, fazer um
        algoritmo que calcule e escreva o numero de anos necessários para que a
        população do país A ultrapasse ou iguale a população do país B, mantidas
        essas taxas de crescimento. */

        /*float a = 90000;
        float b = 200000;
        int y = 0;

        while(a < b){

            a+=(a/100)*3;
            b+=(b/100)*1.5;

            y++;

        }

        System.out.println(a);
        System.out.println(b);
        System.out.println("Anos: " + y);*/

        /*6) Utilizando o comando for mostre a tabuada do 5 na tela. */

        /*for (int i = 0; i <=100;i+=5){

            System.out.println("Tabuada do 5 até 100: " + i);

        } */

        /* 7) Leia sete números e mostre o valor da soma dos sete números */

       /* Scanner teclado = new Scanner(System.in);

        float notas;
        float soma = 0;

        for (int i = 1; i <= 7; i++ ){

            System.out.println("Digite a nota: ");
            notas = teclado.nextFloat();
            soma+= notas; 

        }

        System.out.println("O total é: " + soma);  */ 
    }

}
