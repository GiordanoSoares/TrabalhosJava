
import java.util.Scanner;

public class ExWhile7 {
    
    public static void main(String[] args) {
        
        /* 7) Leia sete números e mostre o valor da soma dos sete números */

        Scanner teclado = new Scanner(System.in);

        int i = 1;
        float notas;
        float soma = 0;

        while(i <=7){

            System.out.println("Digite a nota: " + i);

            notas = teclado.nextFloat();
            soma+= notas;

            i++;

        }

        System.out.println("O total das notas é: " + soma);

    }

}
