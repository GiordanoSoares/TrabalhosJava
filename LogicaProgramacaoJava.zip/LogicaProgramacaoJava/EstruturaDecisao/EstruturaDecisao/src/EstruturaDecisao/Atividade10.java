package EstruturaDecisao;

import java.util.Scanner;

public class Atividade10 {
    
    public static void main(String[] args) {
        
        /*10. Leia três notas de um aluno, a nota 1 vale três pontos, o usuário irá
        digitar um valor entre 0 e 3, a nota 2 também vale três pontos, o usuário
        também irá digitar um valor entre 0 e 3, a terceira nota vale quatro pontos,
        o usuário irá digitar um valor entre 0 e 4, calcule a média, que é a soma
        das três notas obtidas, se a média for maior ou igual a 5 escreva que o
        aluno foi aprovado senão escreva reprovado. */

        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite uma nota entre 0 a 3: ");
        int n1 = teclado.nextInt();

        System.out.println("Digite novamente uma nota entre 0 a 3: ");
        int n2 = teclado.nextInt();
        
        System.out.println("Agora digite uma nota entre 0 a 4: ");
        int n3 = teclado.nextInt();

        int m = (n1+n2+n3);

        if (m >=5) {
            System.out.println("Aprovado");
        }else{
            System.out.println("Reprovado");
        }



    }

}
