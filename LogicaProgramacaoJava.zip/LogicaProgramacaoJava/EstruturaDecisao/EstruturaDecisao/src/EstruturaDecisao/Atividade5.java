package EstruturaDecisao;

import java.util.Scanner;

public class Atividade5 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite sua altura");

        float altura = teclado.nextFloat();

        System.out.println("Digite 1 para feminino ou 2 para masculino");

        int sexo = teclado.nextInt();

        double pesoIdealF = ((altura*62.1) - 44.7);
        double pesoIdealM = ((altura*72.2) - 58);

        if (sexo==1) {

            System.out.println("O peso ideal é: " + pesoIdealF );
            
        }else{
            System.out.println("O peso ideal é: " + pesoIdealM);
        }

    }

}
