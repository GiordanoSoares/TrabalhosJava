package EstruturaDecisao;

import java.util.Scanner;

public class Atividade3 {
    
    public static void main(String[] args) {

        /*3. Leia três notas de um aluno, se a média for maior ou igual a 7, o aluno
        está aprovado, se a média for maior ou igual a 5 e menor que 7, o aluno
        está em recuperação, senão o aluno está reprovado. Mostre a mensagem
        correta. */
        
        Scanner teclado = new Scanner(System.in);

        System.out.println("Diga a primeira nota: ");
            int n1 = teclado.nextInt();

        System.out.println("Diga a segunda nota");
            int n2 = teclado.nextInt();

        System.out.println("Diga a terceira nota");
            int n3 = teclado.nextInt();

        float m = (n1+n2+n3)/3;

        if (m >=5 && m <=7){
            System.out.println("Recuperação");
        }else if (m  >7){
            System.out.println("Aprovado");
        }else{
            System.out.println("Reprovado");
        }

    }

}    