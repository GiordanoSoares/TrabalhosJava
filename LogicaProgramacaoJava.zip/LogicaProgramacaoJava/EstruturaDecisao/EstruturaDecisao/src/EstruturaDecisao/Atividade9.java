package EstruturaDecisao;

import java.util.Scanner;

public class Atividade9 {
    
    public static void main(String[] args) {
        
        /*9. Leia um valor e verifique se ele está no intervalo entre 350 e 500, se
        estiver, escreva uma mensagem informando que o valor está no intervalo
        senão escreva uma mensagem que o valor não se encontra no intervalo. */

        Scanner teclado = new Scanner(System.in);

        System.out.println("Diga um valor de 1 a 1000: ");
        int valor = teclado.nextInt();

        if(valor >=350 && valor <=500){
            System.out.println("Este valor esta no intervalo");
        }else{
            System.out.println("Este valor não se encontra no intervalo");
        }

    }

}
