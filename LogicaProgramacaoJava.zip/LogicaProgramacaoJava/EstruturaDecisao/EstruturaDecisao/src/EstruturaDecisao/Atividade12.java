package EstruturaDecisao;

import java.util.Scanner;

public class Atividade12 {
    
    public static void main(String[] args) {
        
        /*12. Leia um número e verificar se o número digitado foi o número 15, se
        for escreva uma mensagem informando que o número digitado foi o
        número 15, senão escreva que o número digitado não foi o número 15. */

        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite um numéro: ");

        int n1 = teclado.nextInt();

        if(n1 == 15){
            System.out.println("O numero digitado foi o 15");
        }else{
            System.out.println("Não foi o 15");
        }

    }

}
