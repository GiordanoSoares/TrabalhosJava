package EstruturaDecisao;
import java.util.Scanner;

public class Atividade1 {
    public static void main(String[] args) throws Exception {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite o primeiro valor: ");
        int n1 = teclado.nextInt();

        System.out.println("Digite o segundo valor: ");
        int n2 = teclado.nextInt();

        if (n1==n2){
            System.out.println("Os valores sao iguais");
        }else{
            System.out.println("Não são iguais");
        }
    }
}
