package EstruturaDecisao;

import java.util.Scanner;

public class Atividade6 {
    
    public static void main(String[] args) {
        
        /*6. Um vendedor tem seu salário calculado em função do valor total de
        suas vendas. Se o total de vendas for maior que 2000,00, o vendedor
        receberá como salário um bônus de 50,00 mais 10% do valor das vendas.
        Caso contrário, receberá apenas 7,5% do valor das vendas. Faça um
        programa que leia o total de vendas de um vendedor, calcula e imprima
        seu salário. */

        Scanner teclado = new Scanner(System.in);


        System.out.println("Diga seu total de vendas: ");
        float vendas = teclado.nextFloat();

        double bonusMax = (vendas*0.1)+50;
        double bonusMin = (vendas*0.075);

        if(vendas >=2000){

            System.out.println("Recebera de bonus" + bonusMax);

        }else{

            System.out.println("Recebera de bonus: " + bonusMin);

        }


    }
}
