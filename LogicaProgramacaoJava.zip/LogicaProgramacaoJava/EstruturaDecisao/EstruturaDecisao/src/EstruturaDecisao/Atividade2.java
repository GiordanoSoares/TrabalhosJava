package EstruturaDecisao;

import java.util.Scanner;

public class Atividade2 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        System.out.println("Diga um valor: ");
        float valor = teclado.nextFloat();

        if (valor % 2 == 0){

            System.out.println("O valor é par");

        }else{

            System.out.println("O valor é ímpar");

        }


    }

}
