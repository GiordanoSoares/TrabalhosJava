package EstruturaDecisao;

import java.util.Scanner;

public class Atividade7 {
    
    public static void main(String[] args) {
        
        /* 7. Crie um programa que receba 4 notas de um aluno e imprima na tela se
        o aluno foi
        • aprovado (média > 7)
        • reprovado (média <= 7) */

        Scanner teclado = new Scanner(System.in);

        System.out.println("Diga a primeira nota: ");


        int n1 = teclado.nextInt();

        System.out.println("Diga a segunda nota: ");


        int n2 = teclado.nextInt();

        System.out.println("Diga a terceira nota: ");


        int n3 = teclado.nextInt();

        System.out.println("Diga a quarta nota: ");


        int n4 = teclado.nextInt();

        float m = (n1+n2+n3+n4)/4;

        if (m >7){
            System.out.println("Aprovado com média: " + m);
        }else{
            System.out.println("Reprovado média: " + m);
        }
    }

}
