package EstruturaDecisao;

import java.util.Scanner;

public class Atividade11 {
    
    public static void main(String[] args) {

        /*11. Leia um número e verificar se o número é divisível por 8, informar se o
        valor é ou não divisível por 8. */
        
        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite um numero inteiro: ");
        int n1 = teclado.nextInt();

        if (n1 % 8 == 0){
            System.out.println("Divisivel por 8");
        }else{
            System.out.println("Não é divisivel por 8");
        }

    }

}
