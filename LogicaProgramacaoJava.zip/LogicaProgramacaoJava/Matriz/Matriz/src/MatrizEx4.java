
public class MatrizEx4 {
    
    public static void main(String[] args) {
        
        /* 4. Crie um vetor de 5 posições, e insira dentro de suas posições os
        seguintes valores. Logo após escreva os valores do vetor na tela.
        V[0]=50
        V[1]=26
        V[2]=51
        V[3]=18
        V[4]=39 */

        int[] vetor = new int[5];

        vetor[0] = 50;
        vetor[1] = 26;
        vetor[2] = 51;
        vetor[3] = 18;
        vetor[4] = 39;

        for(int i = 0; i <= vetor.length; i++){
        
        System.out.println("valores: " + vetor[i] );

        }


    }

}
