
import java.util.Scanner;

public class MatrizRealEx14 {
    
    public static void main(String[] args) {
        
        /* 14) Ler 4 números e mostrar a média */

        Scanner teclado = new Scanner(System.in);

        int [] valor = new int[4];
        int soma = 0;

        for(int i = 0; i<4; i++){

            System.out.println("Informe o valor: ");
            valor[i] = teclado.nextInt();

            soma +=valor[i];


        }

        double media = soma/4;

        System.out.println("A média é: " + media);

    }

}
