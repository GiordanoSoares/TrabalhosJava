import java.util.Scanner;

public class MatrizRealEx7 {
    
    public static void main(String[] args) {
        
        /* 7) Mostrar apenas números maiores que 100 */

        Scanner teclado = new Scanner(System.in);

        int[] matriz = new int[1];

        for(int i = 0; i < matriz.length; i++){

            System.out.println("Informe o valor: ");
            matriz[i] = teclado.nextInt();

            if(matriz[i]>=100){

                System.out.println("Número informado: " + matriz[i]);

            }else{

                System.out.println("Número menor que 100 informado.");

            }

        }

    }

}
