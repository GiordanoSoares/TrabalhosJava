
import java.util.Scanner;

public class MatrizRealEx9 {
    
    public static void main(String[] args) {
        
        /* 9) Contar quantos são menores que 50 */

        Scanner teclado = new Scanner (System.in);

        int[] matriz = new int[2];
        int quantidade = 0;

        for(int i = 0; i < matriz.length; i++){

            System.out.println("Informa os valores: ");
            matriz[i]=teclado.nextInt();

            if(matriz[i] <=50){

                quantidade+=matriz[i];

            }

        }

        System.out.println("Menores que 50: " + quantidade);

    }

}
