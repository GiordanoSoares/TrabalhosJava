import java.util.Scanner;

public class Matriz2 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int vetor[] = new int[5];

        for(int i = 0; i <=4; i++){

            System.out.println("Informe o valor: ");
            vetor[i] = teclado.nextInt();
            
        }

        for(int i = 0; i <=vetor.length; i++){

            System.out.println("Matrizes ["+ i +"] = " + vetor[i]);


        }

    }

}
