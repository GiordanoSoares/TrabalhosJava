
import java.util.Scanner;

public class MatrizRealEx5 {
    
    public static void main(String[] args) {
        
        /* 5) Contar quantos são iguais a 10 */

        Scanner teclado = new Scanner(System.in);

        int[] vetor = new int[5];

        int quantidade = 0;

        for(int i = 0; i <vetor.length; i++){

            System.out.println("Informe os valores: ");
            vetor[i] = teclado.nextInt();

            if(vetor[i]%10 == 0){

                quantidade++;

            }

            System.out.println("Números iguais a 10: " + quantidade);

        }
    }

}
