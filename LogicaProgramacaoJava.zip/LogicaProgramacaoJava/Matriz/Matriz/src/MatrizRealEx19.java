
import java.util.Scanner;

public class MatrizRealEx19 {
    
    public static void main(String[] args) {
        
        /* 19)Leia 5 notas de um aluno utilizando o comando for, calcule e exiba a média das
        notas do aluno e,
        em seguida, exiba a relação de notas cuja nota é superior a esta média. */

        Scanner teclado = new Scanner(System.in);

        float[] notas =  new float[5];
        float media = 0;

        for(int i = 0; i <notas.length; i++){

            System.out.println("Informe o valor:    ");
            notas[i] = teclado.nextFloat();

            media+=notas[i]/5;

        }

        System.out.println("Média: " + media);

        for(int i = 0; i <notas.length; i++){

            if(notas[i]>media){

                System.out.println("Notas maiores que a média: " + notas[i]);

            }

        }

    }

}
