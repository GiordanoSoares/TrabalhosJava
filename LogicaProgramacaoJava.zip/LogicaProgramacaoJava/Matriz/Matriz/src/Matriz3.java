public class Matriz3 {
    
    public static void main(String[] args) {
        
        /* Inserindo valor fixo a Matrizes */
        
        int vetor[] = new int[5];

        vetor[0] = 0;
        vetor[1] = 1;
        vetor[2] = 2;
        vetor[3] = 3;
        vetor[4] = 4;

        for(int i = 0; i <=vetor.length; i++){

            System.out.println("Os valores são: " + vetor[i]);

        }

    }

}
