import java.util.Scanner;

public class Matriz4 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int [] matriz = new int[5];


        //Preenche os valores da matriz
        for(int i = 0; i<matriz.length; i++){

            System.out.println("Digite os valores da Matriz: " + i);
            matriz[i] = teclado.nextInt();

            //System.out.println("Valores da Matriz: " + matriz[i]);

        }

        //imprime os valores da matriz

        for(int i = 0; i <matriz.length; i++){

            System.out.println("Valores da matriz: " + matriz[i]);

        }

    }

}
