
import java.util.Scanner;

public class MatrizRealEx6 {
    
    public static void main(String[] args) {
        
        /* 6) Ler 3 números e mostrar todos */

        Scanner teclado = new Scanner(System.in);

        int[] matriz = new int[3];

        for(int i = 0; i <matriz.length; i++){

            System.out.println("Informe os valores: ");

            matriz[i] = teclado.nextInt();

        }

        for(int i = 0; i < matriz.length; i++){

            System.out.println("Números informados: " + matriz[i]);

        }

    }

}
