public class MatrizRealEx17 {
    
    public static void main(String[] args) {
        
        /* 17) Crie um array de 5 posições, e insira dentro de suas posições os seguintes
            valores. Logo após
            escreva os valores do vetor na tela.
            V[0]=50
            V[1]=26
            V[2]=51
            V[3]=18
            V[4]=39 */

        int[] vetores = new int[5];

        vetores[0]=50;
        vetores[1]=26;
        vetores[2]=51;
        vetores[3]=18;
        vetores[4]=39;

        for(int i = 0; i < vetores.length; i++){

            System.out.println(vetores[i]);

        }

    }

}
