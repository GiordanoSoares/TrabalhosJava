import java.util.Scanner;

public class MatrizRealEx3 {
    
    public static void main(String[] args) {
        
        /* 3. Calcular e mostrar a média */
        
        Scanner teclado = new Scanner(System.in);

        int vetor[] = new int[2];
        int media = 0;

        for(int i = 0; i <vetor.length; i++){

            System.out.println("Informe o valor: ");
            vetor[i] = teclado.nextInt();

            media+=vetor[i];

        }
        media=media/2;

        System.out.println("A média é: " + media);

    }

}
