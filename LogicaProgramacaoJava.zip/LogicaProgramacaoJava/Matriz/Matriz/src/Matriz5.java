import java.util.Scanner;

public class Matriz5 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int [] gwa = new int[5];
        int soma = 0;

        for(int i = 0; i<gwa.length; i++){

            System.out.println("Digite os valores da Matriz");
            gwa[i] = teclado.nextInt();

            soma += gwa[i];

        }

        for(int i = 0; i<gwa.length; i++){

            System.out.println("Valores da Matrizes: " + gwa[i]);

        }

        System.out.println("\nA soma dos valores da matriz é: " + soma);

        //4,5,8

    }

}
