
import java.util.Scanner;

public class MatrizRealEx15 {
    
    public static void main(String[] args) {
        
        /* 15) Ler 5 números e mostrar os pares */
        
        Scanner teclado = new Scanner(System.in);

        int [] valores = new int[5];

        for(int i = 0; i<5; i++){

            System.out.println("Informe o valor: ");

            valores[i] = teclado.nextInt();

        }

        for (int i = 0; i<5; i++){

            if(valores[i]%2 == 0){

                System.out.println("Pares: " + valores[i]);

            }

        }
    }

}
