import java.util.Scanner;

public class MatrizRealEx10 {
    
    public static void main(String[] args) {
        
        /* 10) Mostrar somente os ímpares */

        Scanner teclado = new Scanner(System.in);

        int[] matriz = new int[1];
        int impares = 0;

        for(int i = 0; i < matriz.length; i++){

            System.out.println("Informe os valores: ");
            matriz[i] = teclado.nextInt();

            if(matriz[i]%2 != 0){

                System.out.println("Número ímpare solicitado: " + matriz[i]);

            }else {

                System.out.println("Não é um número ímpar");

            }

        }

    }

}
