import java.util.Scanner;

public class MatrizRealEx12 {
    
    public static void main(String[] args) {
        
        /* 12) Ler 2 números e mostrar a soma */

        Scanner teclado = new Scanner(System.in);

        int matriz[] = new int[2];
        int soma = 0;

        for(int i = 0; i<matriz.length; i++){

            System.out.println("Informe os valores: ");
            matriz[i] = teclado.nextInt();

            soma+=matriz[i];

        }

        System.out.println("A soma é: " + soma);
    }

}
