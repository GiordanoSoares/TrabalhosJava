import java.util.Scanner;

public class MatrizRealEx2 {
    
    public static void main(String[] args) {
        
        /* 2. Somar os 5 números digitados */

        
        Scanner teclado = new Scanner(System.in);

        int[] vetor = new int[5];
        int soma = 0;

        for(int i = 0; i<vetor.length; i++){

            System.out.println("Insira os valores: ");
            vetor[i] = teclado.nextInt();

            soma+=vetor[i];

        }

        System.out.println("A soma é: " + soma);

    }

}
