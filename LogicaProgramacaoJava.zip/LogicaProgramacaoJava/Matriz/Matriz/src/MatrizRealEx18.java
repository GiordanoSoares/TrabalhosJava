

public class MatrizRealEx18 {
    
    public static void main(String[] args) {
        
        /* 18) Calcule a soma dos valores inteiros contidos em um array de três posições. */

        int[] v = {10, 10, 10};

        int soma = v[0] + v[1] + v[2];

        System.out.println("Soma: " + soma);


    }

}
