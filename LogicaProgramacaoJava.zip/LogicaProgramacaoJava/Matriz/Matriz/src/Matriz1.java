public class Matriz1{

    public static void main(String[] args) {
        
        int [] matriz = new int [5];

        //Imprimir matriz
        for(int i = 0; i <= matriz.length; i++){

            System.out.println("Imprimir valores: " +matriz[i]);

        }

    }

}