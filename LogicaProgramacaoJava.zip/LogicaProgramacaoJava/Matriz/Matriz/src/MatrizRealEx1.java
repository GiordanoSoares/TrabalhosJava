
import java.util.Scanner;

public class MatrizRealEx1 {
    
    public static void main(String[] args) {
        
        /* 1. Ler 5 números e mostrar todos */

        Scanner teclado = new Scanner(System.in);

        int[] vetor = new int[5];

        for(int i = 0; i<vetor.length; i++){

            System.out.println("Insira os valores: ");
            vetor[i] = teclado.nextInt();

        }

        for(int i = 0; i<vetor.length; i++){

            System.out.println("Os valores são ["+i+"] = " + vetor[i]);

        }
    }

}
