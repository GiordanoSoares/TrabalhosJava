import java.util.Scanner;

public class MatrizRealEx8 {
    
    public static void main(String[] args) {
        
        /* 8) Multiplicar cada número por 2 */

        Scanner teclado = new Scanner(System.in);

        int[] matriz = new int[2];

        for(int i = 0; i<matriz.length; i++){

            System.out.println("Informe os valores: ");
            matriz[i] = teclado.nextInt();
            
        }

        for(int i = 0; i<matriz.length; i++){

            System.out.println("Valores informados = ("+matriz[i]+") dobrados: " + matriz[i]*2);

        }

    }

}
