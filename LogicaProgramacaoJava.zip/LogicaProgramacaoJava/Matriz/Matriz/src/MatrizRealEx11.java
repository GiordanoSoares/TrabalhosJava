import java.util.Scanner;

public class MatrizRealEx11 {
    
    public static void main(String[] args) {
        
        /* 11) Ler 4 números e mostrar o último */

        Scanner teclado = new Scanner(System.in);

        int[] matriz = new int[4];


            System.out.println("Informe o primeiro valor: ");
            matriz[0] = teclado.nextInt();

            System.out.println("Informe o segundo valor: ");
            matriz[1] = teclado.nextInt();

            System.out.println("Informe o terceiro valor: ");
            matriz[2] = teclado.nextInt();

            System.out.println("Informe o quarto valor: ");
            matriz[3] = teclado.nextInt();

            System.out.println("O último valor é: " + matriz[3]);
    }

}
