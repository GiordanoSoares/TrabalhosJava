import java.util.Scanner;

public class MatrizRealEx13 {
    
    public static void main(String[] args) {
        
        /* 13) Ler 3 números e mostrar o maior */

        Scanner teclado = new Scanner(System.in);

        int[] numeros = new int[3];

        int maior = Integer.MIN_VALUE;

        for(int i = 0; i < 3; i++) {

            System.out.println("Digite um número: ");
            numeros[i] = teclado.nextInt();

            if(numeros[i] > maior){

                maior = numeros[i];

            }

        }

        System.out.println("Maior número: " + maior);

    }

}
