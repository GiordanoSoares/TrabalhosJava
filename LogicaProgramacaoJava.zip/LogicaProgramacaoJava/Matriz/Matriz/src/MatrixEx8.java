public class MatrixEx8 {
    
    public static void main(String[] args) {
        
        /* 8. Crie um vetor de 9 posições, e insira dentro de suas posições os
        seguintes valores. Logo após escreva os valores do vetor na tela. */

        int[] V = new int[9];

        V[0]  =80;
        V[1] = 95;
        V[2] = 78;
        V[3] = 27;
        V[4] = 39;
        V[5] = 74;
        V[6] = 13;
        V[7] = 96;
        V[8] = 78;

        for(int i = 0; i <V.length; i++){
        
        System.out.println("valores: " + V[i] );

        }

    }

}
