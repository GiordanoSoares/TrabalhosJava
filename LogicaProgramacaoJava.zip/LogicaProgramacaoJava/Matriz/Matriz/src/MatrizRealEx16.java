import java.util.Scanner;

public class MatrizRealEx16 {
    
    public static void main(String[] args) {
        
        /* 16) Ler 3 números e mostrar o dobro de cada */

        Scanner teclado = new Scanner(System.in);

        int [] valores = new int[3];

        for(int i = 0; i<3; i++){

            System.out.println("Informe o valor: ");

            valores[i] = teclado.nextInt();

        }

        for (int i = 0; i<3; i++){

                System.out.println("Valores ["+valores[i]+"] multiplicado por 2: " + valores[i]*2);

        }

    }

}
