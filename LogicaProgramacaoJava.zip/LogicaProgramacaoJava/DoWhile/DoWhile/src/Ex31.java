import java.util.Scanner;

public class Ex31 {
    
    public static void main(String[] args) {
        
        /* 31. Faça um programa utilizando o comando do...while que mostre na tela
    todos os números pares de 101 até 300. */

        Scanner teclado = new Scanner(System.in);

        int par;

        System.out.println("Digite um valor de 101 a 300: ");
        par = teclado.nextInt();


        do { 

            if(par%2==0)

                System.out.println("Números pares: " + par);
                
                par++;

        } while (par <=300);

    }

}
