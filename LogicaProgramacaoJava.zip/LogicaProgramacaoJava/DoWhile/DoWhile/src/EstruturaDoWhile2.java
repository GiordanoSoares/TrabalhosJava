import java.util.Scanner;

public class EstruturaDoWhile2 {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        int opcao, numero;
        boolean continuar = true;
        String empresa, cliente, produto, endereco;
        float preco;

        do { 
            
            System.out.println("Digite 1, 2, 3 ou 4 para sair.");

            opcao = teclado.nextInt();

                switch(opcao){

                    case 1:
                        empresa = teclado.nextLine();
                            System.out.println("Cadastro de Empresa");
                        empresa = teclado.nextLine();

                            System.out.println("Digite o Endereço da empresa: ");
                        endereco = teclado.nextLine();

                            System.out.println("Número do Endereço da empresa: ");
                        numero = teclado.nextInt();

                            System.out.println("Preço da sua empresa: ");
                        preco = teclado.nextInt();

                            System.out.println("Informações da Empresa;" + " \nNome da empresa: " + empresa + " \nEndereço da empresa: " + endereco +
                            " \nNúmero de endereço da empresa: " + numero + " \nValor da empresa: " + preco);
                    break;

                    case 2:
                        cliente = teclado.nextLine();
                            System.out.println("Cadastro de Cliente");
                        cliente = teclado.nextLine();

                            System.out.println("Digite o Endereço do cliente: ");
                        endereco = teclado.nextLine();

                            System.out.println("Número do Endereço do cliente: ");
                        numero = teclado.nextInt();

                            System.out.println("Preço oferecido pelo cliente: ");
                        preco = teclado.nextInt();

                            System.out.println("Informações do Cliente;" + " \nNome do cliente: " + cliente + " \nEndereço do cliente: " + endereco +
                            " \nNúmero de endereço do cliente: " + numero + " \nValor oferecido pelo cliente: " + preco);
                    break;

                    case 3:
                        produto = teclado.nextLine();
                            System.out.println("Cadastro de Produto");
                        produto = teclado.nextLine();

                            System.out.println("Digite o Endereço fabricante do produto: ");
                        endereco = teclado.nextLine();

                            System.out.println("Número de Endereço do fabricante Produto: ");
                        numero = teclado.nextInt();

                            System.out.println("Preço do Produto: ");
                        preco = teclado.nextInt();

                            System.out.println("Informações do Produto;" + " \nNome do produto: " + produto + " \nEndereço do produto: " + endereco +
                            " \nNúmero de endereço do produto: " + numero + " \nValor do produto: " + preco);
                    break;

                    case 4:
                        continuar = false;
                    break;

                    default:
                        System.out.println("Número Inválido");
            }

        } while (continuar);


    }

}
