public class Exercicio14_0 {
    
    public static void main(String[] args) {
        
        /*14)Contar quantos números ímpares existem entre 1 e 50

        Objetivo: Utilizar o for para contar quantos números ímpares existem no
        intervalo de 1 a 50. */

        int quantidade = 0;

        for (int i =1; i <=50; i++){

            if(i%2 != 0) {

                quantidade++;

            }

        }

        System.out.println("Quantidade de números ímpares no intervalo de 1 e 50: " + quantidade);

    }

}
