import java.util.Scanner;

public class Exercicio2 {
    
    public static void main(String[] args) {
        
        /* 2) Faça um software para calcular a área de um triângulo retângulo.
        Fórmula da área. Área=(Base * altura)/2. */

        Scanner teclado = new Scanner(System.in);

        int b ,h;

        System.out.println("Digite a base de seu triângulo retângulo: ");
        b = teclado.nextInt();

        System.out.println("Digite a altura de seu triângulo: ");
        h = teclado.nextInt();

        System.out.println("A área de seu triângulo é: " + (b*h)/2);
        
        teclado.close();
    }

}
