import java.util.Scanner;

public class Exercicio6 {
    
    public static void main(String[] args) {
        
        /* 6) Faça um software que calcule o salário líquido do funcionário da
        empresa XYZ. Leia o salário base e a idade. Calcule o bônus do
        funcionário, sendo o mesmo calculado pela seguinte regra de negócio:
        para funcionários com salário maior ou igual a 1000 e com idade
        superior a 50 anos, receberá 10% de bônus; funcionários com salário
        menor de 1000,00 e com idade até 50 anos receberá somente 5%.
        Imprima o salário base, o bônus do funcionário e o salário líquido. */

        Scanner teclado = new Scanner(System.in);

        double salario;
        int idade;

        System.out.println("Diga seu salário: ");
        salario = teclado.nextDouble();

        System.out.println("Diga sua idade: ");
        idade = teclado.nextInt();

        if(salario >=1000 && idade >=50){

            System.out.println("Seu salário base: " + salario + " \nGanhara de bonus: " + (salario*10)/100 + " \nSalário líquido: " + (salario+(salario*10)/100));
            
        }else{

            System.out.println("Seu salário base: " + salario + " \nGanhara de bonus: " + (salario*5)/100 + " \nSalário líquido: " + (salario+(salario*5)/100));

        }

    }

}
