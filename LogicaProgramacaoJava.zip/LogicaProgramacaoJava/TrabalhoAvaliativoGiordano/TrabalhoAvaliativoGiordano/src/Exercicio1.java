import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[] args) throws Exception {

        /* 1) Faça um algoritmo que leia duas notas de um aluno e apresente na
        tela a média. */

        Scanner teclado = new Scanner(System.in);

        int n1,n2;

        System.out.println("Digite sua nota da primeira prova: ");
        n1 = teclado.nextInt();

        System.out.println("Digite sua nota da segunda prova: ");
        n2 = teclado.nextInt();

        System.out.println("Sua nota é: " + (n1+n2)/2);

        teclado.close();

    }
}
