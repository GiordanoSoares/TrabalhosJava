import java.util.Scanner;

public class Exercicio10 {
    
    public static void main(String[] args) {

        /*10) Utilizando o do while resolva a questão abaixo. Lembre do tipo Boolean.
        Apresente um menu para o usuário com 4 opções. A) Cadastrar produto
        B) Cadastrar Fornecedor
        C) Cadastar Cliente
        D) Sair
        E) Para questões A,B,C deverá conter os respectivos cadastros, Para
        produto: Cadastrar produto e quantidade, Para fornecedor:
        Cadastrar fornecedor e Cadastrar cidade, Para Cliente, Cadastrar
        cliente e cidade.
        F) Repetir o menu para o usuário se deseja continuar cadastrando e
        informar os menus, para sair digite */
        
        Scanner teclado = new Scanner(System.in);

        int opcao, quantidade;
        boolean continuar = true;
        String produto, fornecedor, cliente, cidade;

        do { 
            
            System.out.println("Digite 1, 2, 3 ou 4 para sair.");

            opcao = teclado.nextInt();

                switch(opcao){

                    case 1:
                        produto = teclado.nextLine();
                            System.out.println("Cadastre o nome do Produto");
                        produto = teclado.nextLine();

                            System.out.println("Digite a quantidade de Produto: ");
                        quantidade = teclado.nextInt();

                            System.out.println("Informações do Produto;" + " \nNome do Produto: " + produto + " \nQuantidade de Produto: " + quantidade);
                    break;

                    case 2:
                    fornecedor = teclado.nextLine();
                        System.out.println("Cadastre o Fornecedor");
                    fornecedor = teclado.nextLine();

                        System.out.println("Digite a cidade do Fornecedor: ");
                    cidade = teclado.nextLine();

                        System.out.println("Informações do Fornecedor;" + " \nNome do Fornecedor: " + fornecedor + " \nCidade do Fornecedor: " + cidade);
                    break;

                    case 3:
                    cliente = teclado.nextLine();
                        System.out.println("Cadastre o Cliente");
                    cliente = teclado.nextLine();

                        System.out.println("Digite a cidade do Cliente: ");
                    cidade = teclado.nextLine();

                        System.out.println("Informações do Cliente;" + " \nNome do Cliente: " + cliente + " \nCidade do Cliente: " + cidade);
                    break;

                    case 4:
                        continuar = false;
                    break;

                    default:
                        System.out.println("Número Inválido");
            }

        } while (continuar);


    }

}

