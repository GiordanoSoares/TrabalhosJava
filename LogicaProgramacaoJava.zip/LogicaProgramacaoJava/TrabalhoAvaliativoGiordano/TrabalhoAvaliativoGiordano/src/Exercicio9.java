import java.util.Scanner;

public class Exercicio9 {

    public static void main(String[] args) {
        
        /*9) Desenvolver um algoritmo que peça o código do cliente, se o código
        for igual a 1, apresentar uma mensagem de (“Olá você terá acesso a
        um parte do sistema”), caso se 2 (“você tem acesso parcial ao sistema
        ”) caso seja 3 (“você é o administrador do sistema”).
        A ) Se for (Cód 1) pedir senha de acesso e nome do usuário*, a senha 123
        (“OK”) senão
        verifique seu usuário e senha
        B) Se for (Cód 2) pedir senha de acesso e nome do usuário*, a senha 456
        (“OK”) senão
        verifique seu usuário e senha

        C) Se for (Cód 3) pedir senha de acesso e nome do usuário*, a senha 789
        (“OK”) senão verifique seu usuário e senha
        * Utilize o equals */

        Scanner teclado = new Scanner(System.in);

        int cod, senha;
        String  usuario, adm = "Giordano", adm2 = "Germano", adm3 = "Brian";
        boolean continuar = true;

            System.out.println("Digite 1, 2 ou 3: ");
            cod = teclado.nextInt();
    
                switch (cod) {
                    case 1:
                        usuario = teclado.nextLine();
                            System.out.println("Olá você terá acesso a uma parte do sistema");
                            System.out.println("Para isso, digite o seu nome de usuário: ");
                        usuario = teclado.nextLine();
                            System.out.println("Agora sua senha: ");
                        senha = teclado.nextInt();

                        if (senha == 123 && usuario.equals(adm)){

                            System.out.println("Login realizado.");

                        }else{

                            System.out.println("Verifique seu usuario e senha.");

                        }
                    break;

                    case 2:
                    usuario = teclado.nextLine();
                        System.out.println("Olá você tem acesso a grande parte do sistema");
                        System.out.println("Para isso, digite o seu nome de usuário: ");
                    usuario = teclado.nextLine();
                        System.out.println("Agora sua senha: ");
                    senha = teclado.nextInt();

                    if (senha == 456 && usuario.equals(adm2)){

                        System.out.println("Login realizado.");

                    }else{

                        System.out.println("Verifique seu usuario e senha.");

                    }
                    break;

                    case 3:
                    usuario = teclado.nextLine();
                        System.out.println("Olá você será administrador do sistema");
                        System.out.println("Para isso, digite o seu nome de usuário: ");
                    usuario = teclado.nextLine();
                        System.out.println("Agora sua senha: ");
                    senha = teclado.nextInt();

                    if (senha == 789 && usuario.equals(adm3)){

                        System.out.println("Login realizado.");

                    }else{

                        System.out.println("Verifique seu usuario e senha.");

                    }
                    break;
                }

    }

}
