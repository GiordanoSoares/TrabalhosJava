import java.util.Scanner;

public class Exercicio4 {
    
    public static void main(String[] args) {
        
        /* 4) Faça um software que leia a idade de uma pessoa expressa em anos,
        meses e dias e mostre-a expressa apenas em dias. Considerar que
        cada ano possua 365 dias e que cada mês possua 30 dias. */

        int anos, meses, dias;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Quantos anos viveu até o momento? ");
        anos = teclado.nextInt();

        System.out.println("Quantos meses viveu até o momento? ");
        meses = teclado.nextInt();

        System.out.println("Quantos dias viveu até o momento? ");
        dias = teclado.nextInt();

        float onlyDias = anos*365+meses*30+dias;

        System.out.println("Até o momento você viveu: " + onlyDias);

        

    }

}
