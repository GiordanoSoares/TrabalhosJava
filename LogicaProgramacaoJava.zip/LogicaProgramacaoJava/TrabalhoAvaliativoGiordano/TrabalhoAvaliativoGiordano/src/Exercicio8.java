
import java.util.Scanner;

public class Exercicio8 {
    
    public static void main(String[] args) {
        
        /* 8) Leia um número e verificar se o número digitado foi o número 15, se
        for escreva uma mensagem informando que o número digitado foi o
        número 15, senão escreva que o número digitado não foi o número
        15. */

        Scanner teclado = new Scanner(System.in);

        int n;

        System.out.println("Digite um número inteiro de 1 a 30: ");
        n = teclado.nextInt();

        if (n == 15) {
            
            System.out.println("Dos 30, você escolheu o certo! Número: " + n);

        }else{

            System.out.println("Número errado... " + n);

        }


    }

}
