import java.util.Scanner;

public class Exercicio12_0 {
    
    public static void main(String[] args) {
        
        /* 12)Imprimir a tabuada de um número
        Objetivo: Usar o for para imprimir a tabuada de um número dado pelo usuário. */

        Scanner teclado = new Scanner(System.in);

        int n, i;

        System.out.println("Digite um número de direi a tabuada até certo ponto.");
        n = teclado.nextInt();

        for(i = 1; i<=100; i++){

            System.out.println(i*n);

        }

    }

}
