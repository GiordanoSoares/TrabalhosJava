import java.util.Scanner;

public class Exercicio5 {
    
    public static void main(String[] args) {
        
        /* 5) Leia três notas de um aluno, se a média for maior ou igual a 7, o aluno
        está aprovado, se a média for maior ou igual a 5 e menor que 7, o
        aluno está em recuperação, senão o aluno está reprovado. Mostre a
        mensagem correta. */

        Scanner teclado = new Scanner(System.in);

        int n1,n2, n3;

        System.out.println("Digite sua nota da primeira prova: ");
        n1 = teclado.nextInt();

        System.out.println("Digite sua nota da segunda prova: ");
        n2 = teclado.nextInt();

        System.out.println("Digite sua nota da terceira prova: ");
        n3 = teclado.nextInt();

        int m = (n1+n2+n3)/3;

        if(m >=7 ){

            System.out.println("Aprovado! Nota: " + m);

        }else if(m >=5 && m <=7){

            System.out.println("Recuperação! Nota: " + m);

        }else {

            System.out.println("Reprovado, decepcionante... Nota: " + m);

        }

        }

    }

