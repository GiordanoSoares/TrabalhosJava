
import java.util.Scanner;

public class Exercicio13_0 {
    
    public static void main(String[] args) {
        
        /* 13)Soma dos números de 1 a 100
        Objetivo: Usar o for para somar os números de 1 a 100 e imprimir o
        resultado. */

        Scanner teclado = new Scanner(System.in);

        int soma = 0;

        for (int i = 1; i <=100; i++){

            soma +=i;

        }

        System.out.println("A soma dos números de 1 a 100 é: " + soma);

    }

}
