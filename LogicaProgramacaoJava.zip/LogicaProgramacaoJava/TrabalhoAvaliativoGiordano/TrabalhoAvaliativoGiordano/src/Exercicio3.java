import java.util.Scanner;

public class Exercicio3 {
    
    public static void main(String[] args) {
        
    /* 3) Elaborar um software que calcule e apresente o volume de uma caixa
    retangular, por meio da fórmula:
    VOLUME = COMPRIMENTO * LARGURA * ALTURA */

        Scanner teclado = new Scanner(System.in);

        int c, l ,h;

        System.out.println("Diga o comprimento da sua caixa: ");

        c = teclado.nextInt();

        System.out.println("Diga a largura da sua caixa: ");

        l = teclado.nextInt();

        System.out.println("Diga a altura da sua caixa: ");

        h = teclado.nextInt();

        System.out.println("O volume da sua caixa é igual a: " + (c*l*h));

        teclado.close();
    }

    
}
